package com.example.demo111.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo111.entity.Malladmin;
public interface MalladminRepository extends JpaRepository<Malladmin,Integer>{
	
}
