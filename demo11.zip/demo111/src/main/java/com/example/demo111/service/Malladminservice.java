package com.example.demo111.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo111.entity.Malladmin;
import com.example.demo111.repository.MalladminRepository;

@Service
public class Malladminservice {
	
	@Autowired
	public MalladminRepository mrepo;
	
	//inserting data
	public Malladmin addMalladmin( Malladmin malladmin) {
		return mrepo.save(malladmin);
	}

	//getting the data from database
	public List<Malladmin> getMalladmin() {
		return mrepo.findAll();
	}
	
	//delete the data from database
	public void deleteMalladmin(int id) {
		mrepo.deleteById(id);
	}

	

	
}
	