package com.example.demo111.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo111.entity.Malladmin;
import com.example.demo111.service.Malladminservice;

//controller class communicates with postman
//execution flow
//postman->controller->service->repository->database
@RestController
public class MalladminController {
	
	
	@Autowired
	public Malladminservice mser;
	
	//insert
	@PostMapping("/addMalladmin")
	public Malladmin addMalladmin(@RequestBody Malladmin malladmin) {
		return mser.addMalladmin( malladmin);
	}
	
	//get
		@GetMapping("/getMalladmin")
		public List<Malladmin> getMalladmin() {
			return mser.getMalladmin();
		}
		
	//delete
		@DeleteMapping("/deleteMalladmin/{id}")
		public void deleteMalladmin(@PathVariable int id) {
			 mser.deleteMalladmin(id);
		}
}
