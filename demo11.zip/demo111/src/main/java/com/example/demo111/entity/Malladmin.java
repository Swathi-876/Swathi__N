package com.example.demo111.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Table
@Entity
public class Malladmin {
	@Id
	private int id;
	private String name;
	private String password;
	private long phonenumber;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getname() {
		return name;
	}
	public String getpassword() {
		return password;
	}
	public long getphonenumber() {
		return phonenumber;
	}
	public static void run(Class<Malladmin> class1, String[] args) {
		// TODO Auto-generated method stub
		
	}
}

	


