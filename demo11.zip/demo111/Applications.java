package com.example.demo111;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo111.entity.Malladmin;

@SpringBootApplication
public class Applications {

	public static void main(String[] args) {
		SpringApplication.run(Malladmin.class,args);
		// TODO Auto-generated method stub

	}

}
